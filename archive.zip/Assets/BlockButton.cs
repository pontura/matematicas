﻿using UnityEngine;
using System.Collections;

public class BlockButton : MonoBehaviour {
    public int id;
}
