﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class BlockItem : MonoBehaviour {

    public Text inputField;

	void Start () {
	
	}
}
